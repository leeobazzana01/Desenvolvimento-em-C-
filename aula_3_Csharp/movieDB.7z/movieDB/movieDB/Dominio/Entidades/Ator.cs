﻿namespace movieDB.Dominio.Entidades
{
    public class Ator
    {
        public string Nome { get; set; }
        public string Nacionalidade { get; set; }
    }
}

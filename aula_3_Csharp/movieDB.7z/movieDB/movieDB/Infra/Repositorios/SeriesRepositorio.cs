﻿using movieDB.Dominio.Entidades;

namespace movieDB.Infra.Repositorios
{
    public class SeriesRepositorio: IRepositorio<Serie>
    {
        public Task BuscaDado(Serie serie)
        {
            return null;
        }
        public Task InsereDado(Serie serie)
        {
            return null;
        }
        public Task AtualizaDado(Serie serie)
        {
            return null;
        }
        public Task DeletaDado(Serie serie)
        {
            return null;
        }
    }
}

﻿using movieDB.Dominio.Entidades;

namespace movieDB.Infra.Repositorios
{
    public class FilmeRepositorio: IRepositorio<Filme>
    {
        public Task BuscaDado(Filme filme)
        {
            return null;
        }
        public Task InsereDado(Filme filme) 
        {
            return null;
        }
        public Task AtualizaDado(Filme filme)
        {
            return null;
        }
        public Task DeletaDado(Filme filme)
        {
            return null;
        }
    }
}
